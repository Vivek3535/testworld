import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-loginPannel',
  templateUrl: 'loginPannel.html'
})
export class loginPannel { 
 
  constructor(public navCtrl: NavController) {

  } 

}
