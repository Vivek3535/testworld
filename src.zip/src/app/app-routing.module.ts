// import { RouterModule, Routes } from '@angular/router';
// import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
// import { HomePage } from '../pages/home/home';
 
// export const AppRoutes: Routes = [
//     { path: 'home', component: HomePage }
// ];
 
// export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);